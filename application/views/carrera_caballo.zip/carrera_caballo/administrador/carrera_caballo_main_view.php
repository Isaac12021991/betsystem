      <link href="<?php echo base_url(); ?>assets/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
                    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
                        <!--begin::Subheader-->
                        <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
                            <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                                <!--begin::Info-->
                                <!--begin::Info-->
                                <div class="d-flex align-items-center flex-wrap mr-2">

                                    <!--begin::Actions-->
                                    <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">Carrera de caballos</h5>
                                <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-4 bg-gray-200"></div>


        <div class="btn-group ml-2">
                    <button type="button" class="btn btn-sm btn-light-primary font-weight-bold dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Accion
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu" style="">
                        <a class="dropdown-item" onclick="accion_masiva_check('Iniciar')" href="javascript::">Iniciar</a>
                        <a class="dropdown-item" onclick="accion_masiva_check('Finalizar')" href="javascript::">Finalizar</a>
                        <a class="dropdown-item" href="javascript::" onclick="accion_masiva_check('Eliminar')">Eliminar</a>
                    </div>
                </div>


        
                                </div>
                                <!--end::Info-->
                                <!--begin::Toolbar-->
                                <div class="d-flex align-items-center">
                                <form id="filtro_form" method="GET" action="<?= site_url('/carrera_caballo/index') ?>" class="mr-2 ml-2">
                                    <div class="row">
                                        <div class="col-6 pr-0 pl-0">
                                <select class="form-control form-control-solid form-control-sm mr-0" id="nb_modo_juego" name="nb_modo_juego" onChange="filtro_carrera()">
                                    <option value="">Modo de Juego:</option>
                                    <option value="">Todo</option>
                                    <option value="Remate">Remate</option>
                                    <option value="Ganadores">Ganadores</option>
                                    </select>
                                    </div>

                                    <div class="col-6">
                                <select class="form-control form-control-solid form-control-sm mr-0" id="nb_sede" name="nb_sede" onChange="filtro_carrera()">
                                    <option value="">Hipodromo:</option>
                                   <?php foreach($lista_sede->result() as $row){
                                    echo "<option value='".$row->nb_sede."'>".$row->nb_sede."</option>";
                                    } ?>
                                    </select>
                                    </div>

                                    </div>

                                    </form>
                                          
                                          
                  
           
                                    
                                <a href="<?php echo site_url("carrera_caballo/nueva_carrera");?>" class="btn btn-light-primary font-weight-bolder btn-sm mr-2">Crear</a>

                                    <!--end::Actions-->
                                    <!--begin::Dropdown-->
                                            <!--end::Dropdown-->
                                </div>
                                <!--end::Toolbar-->
                            </div>
                        </div>
                        <!--end::Subheader-->
                        <!--begin::Entry-->
                        <div class="d-flex flex-column-fluid">
                            <!--begin::Container-->
                            <div class="container">
                                <div class="row">

                                <div class="col-lg-1">
                                    
                                    
                                </div>

                                <div class="col-lg-10">


                                    <div class="card card-custom gutter-b" id="div_body">
                                    <div class="card-header">
                                    <div class="card-title">
                                    <h3 class="card-label">
                                    Salas
                                    <small></small>
                                    </h3>
                                    </div>
                                    </div>
                                    <div class="card-body pl-2 pr-2 pt-0">

                                          <?php $con = 0; if (isset($salas)) : ?>
             <?php if ($salas->num_rows() > 0) : ?>
            
            <table class="table table-hover dt-responsive nowrap table-sm table-striped" id="myTable" width="100%">
               <thead class="">
                  <tr>
                    <th class="text-center align-middle"><input type="checkbox" name="checkall" id="checkall" /></th>
                    <th>Creado el</th>
                     <th class="all">Modo de Juego</th>
                     <th>Carrera </span> </th>
                     <th class="text-center align-middle"> Hipodromo</th>
                     <th class="text-center align-middle">Distancia Mts</th>
                     <th class="text-center align-middle all">Estatus</th>
                     <th class="text-center align-middle all"></th>
                  </tr>
               </thead>
               <tbody>
                  <?php foreach ($salas->result() as $row) : ?>
                  <tr>
                    <td class="text-center align-middle"> <input type="checkbox" class="checkbox_comprobar check_get" name="accion_check" id="accion_check" value="<?php echo $row->id; ?>" />   </td>
                    <td>   <?php if($row->ff_sistema_time != 0): ?>  <?php echo date('d-m-Y',$row->ff_sistema_time); ?><br> <?php echo date('h:i:s a', $row->ff_sistema_time); ?> <?php endif; ?>  <span class="d-block d-sm-none">  <?php echo date('d-m-Y',$row->ff_sistema_time); ?>  </td>
                     <td> <?php echo $row->nb_modo_juego; ?> <span class="d-block d-lg-block"> <?php echo $row->nb_sede; ?> </span> </td>
                     <td>   <?php echo $row->nu_carrera; ?>   </td>
                     <td class="text-center align-middle">  <?php echo $row->nb_sede; ?> </td>
                     <td class="text-center align-middle">  <?php echo $row->nu_distancia; ?> </td>
                      <td class="text-center align-middle"> 
                        <?php if($row->nb_estatus == 'EN ESPERA'): ?> <span class="label label-lg label-light-primary label-inline"> <?php echo $row->nb_estatus; ?> </span> <?php endif; ?>
                      <?php if($row->nb_estatus == 'INICIADO'): ?> <span class="label label-lg label-light-success label-inline"> <?php echo $row->nb_estatus; ?> </span> <?php endif; ?>
                       <?php if($row->nb_estatus == 'FINALIZADO'): ?> <span class="label label-lg label-light-info label-inline"> <?php echo $row->nb_estatus; ?> </span> <?php endif; ?>
               <?php if($row->nb_estatus == 'CERRADA'): ?> <span class="label label-lg label-light-danger label-inline"> <?php echo $row->nb_estatus; ?> </span> <?php endif; ?>
                        </td>
                     <td class="text-center align-middle">

                                        <div class="dropdown dropdown-inline mr-4">
                    <button type="button" class="btn btn-light-primary btn-icon btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <i class="ki ki-bold-more-hor"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-md dropdown-menu-right">
                        <a class="dropdown-item" href='<?php echo site_url("carrera_caballo/editar_carrera/$row->id");?>'>Editar</a>
                        <a class="dropdown-item" href="<?php echo site_url("carrera_caballo/ver_sala_modo_administrador/$row->id");?>">Ver carrera</a>
                         <?php if($row->nb_estatus == 'FINALIZADO'): ?> 
                        <a class="dropdown-item" onclick="elegir_ganador(<?php echo $row->id; ?>)" href="javascript:">Elegir ganador</a>
                    <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" onclick="cambiar_estatus('INICIADO', '<?php echo $row->id; ?>')" href="javascript:">Iniciar</a>

                       <a class="dropdown-item" onclick="cambiar_estatus('FINALIZADO', '<?php echo $row->id; ?>')" href="javascript:">Finalizar</a>

                        <a class="dropdown-item" onclick="cambiar_estatus('CERRADA', '<?php echo $row->id; ?>')" href="javascript:">Cerrada</a>

                         <div class="dropdown-divider"></div>

                     <a class="dropdown-item" onclick="duplicar_registro('<?php echo $row->id; ?>')" href="javascript:">Duplicar</a>

                        <a class="dropdown-item" onclick="eliminar_carrera_caballo(<?php echo $row->id; ?>)" href="javascript:">Eliminar</a>


                    </div>
                </div>


     



                     </td>
                  </tr>
                  <?php endforeach; ?>   
               </tbody>
            </table>
      
            <?php else: ?>
            <h4>Sin registros</h4>
            <p>Sin registro</p>
            <?php endif; ?>
             <?php endif; ?>




                                    </div>
                                    </div>

                                          



    

                            </div>



                                <div class="col-lg-1"></div>

                            </div>

                            </div>
                            <!--end::Container-->
                        </div>
                        <!--end::Entry-->
                    </div>


    <div class="modal fade"  id="ajax_remote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog"  role="document">
        <div class="modal-content">

        </div>
    </div>
</div>

<script type="text/javascript">

//document.getElementById('div_body').style.display='none';


   $("#checkall").change(function () {
   
   $("input:checkbox").prop('checked', $(this).prop("checked"));
   
   
   });



$('#nb_modo_juego').val('<?php echo $nb_modo_juego; ?>');
$('#nb_sede').val('<?php echo $nb_sede; ?>');

function filtro_carrera() {

$('#filtro_form').submit();
    // body...
}



   $(document).ready(function(){

    document.getElementById('div_body').style.display='block';

   $('#myTable').dataTable({searching: false, paging: false, info: false, aaSorting: []});

      jQuery('#ajax_remote').on('hidden.bs.modal', function (e) {
    jQuery(this).removeData('bs.modal');
    jQuery(this).find('.modal-content').html('Cargando...');
   })
   

   }); // Fin ready
   
   

                        function elegir_ganador(co_sala) {

                            $.get("<?php echo site_url('carrera_caballo/elegir_ganador/') ?>" + co_sala,
                            function(data){
                            if (data != "") {
                                $('#ajax_remote').modal('show');
                                $('#ajax_remote .modal-content').html(data);
                            }            
                                      }

                            );  

                            
                            }


                                  function eliminar_carrera_caballo(co_sala)
   {
   
   
                       $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Eliminar',
   content: '¿Estas seguro que deseas eliminar esta sala?.',
   type: 'red',
   animation: 'opacity',
   autoClose: 'no|10000',
   escapeKey: 'no',
   buttons: {
   si: function () {
   
            $.ajax({
   method: "POST",
   data: {'co_sala':co_sala},
   url: "<?php echo site_url('carrera_caballo/eliminar_carrera_caballo') ?>",
            }).done(function( data ) { 
   
               var obj = JSON.parse(data);
   
              $(location).attr('href',"<?php echo site_url() ?>carrera_caballo/index");
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   },
   no: function () {
   
   
   
   },
   
   }
   });

   
   
   }


   
            function cambiar_estatus(nb_estatus, co_sala)
   {
   
                                                 $.ajax({
   method: "POST",
   data: {'nb_estatus':nb_estatus, 'co_sala':co_sala},
   url: "<?php echo site_url('carrera_caballo/cambiar_estatus_carrera') ?>",
   beforeSend: function(){  },
                }).done(function( data ) { 

                    var obj = JSON.parse(data);


                      if (obj.error == 0) {

                     location.reload();
   

                       }else{
              
                          toastr.error(obj.message, 'Error');
                         return;

                       }


   

                 }).fail(function(){
   
               alert('Fallo');
   
   
                 }); 
      
      
   
   }


    function duplicar_registro(co_sala)
   {
   
   
                       $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Duplicar',
   content: '¿Estas seguro que deseas duplicar esta sala?.',
   type: 'blue',
   animation: 'opacity',
   autoClose: 'no|10000',
   escapeKey: 'no',
   buttons: {
   si: function () {
   
            $.ajax({
   method: "POST",
   data: {'co_sala':co_sala},
   url: "<?php echo site_url('carrera_caballo/duplicar_registro') ?>",
            }).done(function( data ) { 
   
               var obj = JSON.parse(data);
   
              $(location).attr('href',"<?php echo site_url() ?>carrera_caballo/editar_carrera/" + obj.message);
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   },
   no: function () {
   
   
   
   },
   
   }
   });
   
   
   
   
   }



   
   function accion_masiva_check(nb_accion)
   {
   

        var selected = new Array();
        $(".check_get:checked").each(function () {
            selected.push(this.value);
        });

      if (selected.length === 0) { toastr.error("Error", 'Por favor seleccione una carrera');  return false; }

   
                       $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: nb_accion,
   content: '¿Estas seguro que deseas '+nb_accion+' estas carreras ?.',
   type: 'red',
   animation: 'opacity',
   autoClose: 'no|10000',
   escapeKey: 'no',
   buttons: {
   si: function () {
   
                                          $.ajax({
   method: "POST",
   data: {'input_check':selected, 'nb_accion':nb_accion},
   url: "<?php echo site_url('carrera_caballo/accion_masiva_check') ?>",
   beforeSend: function(){  },
            }).done(function( data ) { 
   
               var obj = JSON.parse(data);
   
                toastr.info("Exito", obj.message);
   
           location.reload();
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   },
   no: function () {
   
   
   
   },
   
   }
   });
   
   
   
   
   }
   
</script>
