
                    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
                        <!--begin::Subheader-->
                        <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
                            <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                                <!--begin::Info-->
                                <!--begin::Info-->
                                <div class="d-flex align-items-center flex-wrap mr-2">

                                    <!--begin::Actions-->
                                    <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">Carrera de caballos</h5>
                                <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-4 bg-gray-200"></div>


        
                                </div>
                                <!--end::Info-->
                                <!--begin::Toolbar-->
                                <div class="d-flex align-items-center">

    
                                          
                                    <!--end::Actions-->
                                    <!--begin::Dropdown-->
                                            <!--end::Dropdown-->
                                </div>
                                <!--end::Toolbar-->
                            </div>
                        </div>
                        <!--end::Subheader-->
                        <!--begin::Entry-->
                        <div class="d-flex flex-column-fluid">
                            <!--begin::Container-->
                            <div class="container">
                                <div class="row">




                                <div class="col-lg-12">



                                                                        <div class="row mb-0">
                                        
                                        <div class="col-lg-12">

                                    <table class="table display-5">
                                    <thead>
                                    <tr class="thead-dark">
                                    <th>Hipodromo </th> <th> Carrera nro: <?php echo $info_sala->nu_carrera; ?> </th><th>  </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr class="table-light"><td><?php echo $info_sala->nb_sede; ?></td><td>Distancia: <?php echo $info_sala->nu_distancia; ?></td><td></td></tr>
                                    </tbody>
                                    <tfoot>
                                    <tr class="table-light"><td colspan="3"><marquee><?php echo $info_sala->nb_anuncio_uno; ?>  <?php echo $info_sala->nb_anuncio_dos; ?></marquee></td></tr>

                                    </tfoot>
                                    </table>


                                      
                                          </div>



                                            
                                    </div>


 

                                    <div class="row">

                                          <div class="col-lg-6 mt-2">

                                            <div class="card card-custom">
                                        <div class="card-header">
                                        <div class="card-title">
                                                <span class="card-icon">
                                                    <i class="flaticon2-chat-1 text-primary"></i>
                                                </span>
                                        <h3 class="card-label">
                                        Ganadores
                                        <small>Apostar al primer lugar</small>
                                        </h3>
                                        </div>

                                        </div>
                                        <div class="card-body">
                                        <?php if ($sala_linea->num_rows() > 0): $ca_total_tabla = 0; ?>
                                             <table class="table display-4 table-sm">
                                                <thead>
                                                <tr>
                                                <th  class="text-center align-middle" width="33%"> # </th> 
                                                <th  class="text-center align-middle" width="33%"> Apostado</th>
                                                <th  class="text-center align-middle" width="33%"> </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                            <?php foreach ($sala_linea->result() as $row): ?>
                                                <tr>
                                                    <td  class="text-center align-middle">  <span class="btn display-4 pt-1 pb-1" 
                                                        style="background:<?php echo $row->nu_color; ?>"><?php echo $row->nu_casilla; ?></span> </td>
                                                    <td  class="text-center align-middle"><span id="ca_monto_apostado_<?php echo $row->id ?>_1"> <?php $ca_monto_apostado = $this->carrera_caballo_library->get_info_apostado($row->id, '1'); 
                                                            echo number_format($ca_monto_apostado, 0, ',','.'); ?> </span></td>
                                                    <td  class="text-center align-middle">
                                                        <span id="boton_accion_apuesta_ganadores_<?php echo $row->id ?>_1">
                                                        <?php if($ca_monto_apostado == 0): ?>
                                                    
                                                    <a href="javascript:" onclick="ejecutar_apuesta('<?php echo $row->id; ?>', '1')" class="btn btn-outline-primary btn-circle">
                                                    <i class="far fa-hand-point-up"></i></a>
                                                   
                                                <?php else: ?>

                                                <a href="javascript:" class="btn btn-outline-success btn-circle">
                                                    <i class="fas fa-check"></i></a>

                                                <?php endif; ?>

                                                 </span>
                                                     </td>
                                                </tr>

                                            <?php   $ca_total_tabla += $ca_monto_apostado;  endforeach; ?>
                                                </tbody>
                                            </table>

                                           <table class="table table-sm">
                                                   <tr>
                                                <td  class="text-right align-middle" width="33%"> Total tabla:</td> <td> <?php echo number_format($ca_total_tabla, 2, ',','.');  ?>  </td> 
                                                </tr>
                                                                                                   <tr>
                                                <td  class="text-right align-middle" width="33%"> Pago cliente: </td> <td>  <?php $info_pago_cliente = $this->reporte_library->get_reportes_ganadores_pagos($info_sala->id, 1); echo number_format($info_pago_cliente->ca_monto_pago, 2, ',','.');   ?>  </td> 
                                                </tr>
                                                <tr>
                                                <td  class="text-right align-middle" width="33%"> Total casa: </td> <td>  <?php $ca_total_casa = $ca_total_tabla -$info_pago_cliente->ca_monto_pago; ?>  

                                                <?php echo number_format($ca_total_casa, 2, ',','.');  ?>  </td> 
                                                </tr>

                                            </table>


                                        <?php endif; ?>
                                        </div>
                                        </div>

                                          </div>

                                            
                                        <div class="col-lg-6 mt-2">

                                            <div class="card card-custom">
                                <div class="card-header">
                                <div class="card-title">
                                        <span class="card-icon">
                                            <i class="flaticon2-chat-1 text-primary"></i>
                                        </span>
                                <h3 class="card-label">
                                Place
                                <small>Apostar al segundo lugar</small>
                                </h3>
                                </div>

                                </div>
                                <div class="card-body">
                                 <?php if ($sala_linea->num_rows() > 0): $ca_total_tabla = 0; ?>
                                             <table class="table display-4 table-sm">
                                                <thead>
                                                <tr>
                                                <th  class="text-center align-middle" width="33%"> # </th> 
                                                <th  class="text-center align-middle" width="33%"> Apostado</th>
                                                <th  class="text-center align-middle" width="33%"> </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                            <?php foreach ($sala_linea->result() as $row):  ?>
                                                <tr>
                                                    <td  class="text-center align-middle">  <span class="btn display-4 pt-1 pb-1" 
                                                        style="background:<?php echo $row->nu_color; ?>"> <?php echo $row->nu_casilla; ?></span> </td>
                                                    <td  class="text-center align-middle"><span id="ca_monto_apostado_<?php echo $row->id ?>_2"> <?php $ca_monto_apostado = $this->carrera_caballo_library->get_info_apostado($row->id, '2'); 
                                                            echo number_format($ca_monto_apostado, 0, ',','.'); ?> </span></td>
                                                                <td  class="text-center align-middle">
                                                        <span id="boton_accion_apuesta_ganadores_<?php echo $row->id ?>_2">
                                                        <?php if($ca_monto_apostado == 0): ?>
                                                    
                                                    <a href="javascript:" onclick="ejecutar_apuesta('<?php echo $row->id; ?>', '2')" class="btn btn-outline-primary btn-circle">
                                                    <i class="far fa-hand-point-up"></i></a>
                                                   
                                                <?php else: ?>

                                                <a href="javascript:" class="btn btn-outline-success btn-circle">
                                                    <i class="fas fa-check"></i></a>

                                                <?php endif; ?>

                                                 </span>
                                                     </td>
                                                </tr>

                                              

                                            <?php   $ca_total_tabla += $ca_monto_apostado;  endforeach; ?>
                                                </tbody>
                                            </table>

                                           <table class="table table-sm">
                                                   <tr>
                                                <td  class="text-right align-middle" width="33%"> Total tabla:</td> <td> <?php echo number_format($ca_total_tabla, 2, ',','.');  ?>  </td> 
                                                </tr>
                                                                                                   <tr>
                                                <td  class="text-right align-middle" width="33%"> Pago cliente: </td> <td>  <?php $info_pago_cliente = $this->reporte_library->get_reportes_ganadores_pagos($info_sala->id, 2); echo number_format($info_pago_cliente->ca_monto_pago, 2, ',','.');   ?>  </td> 
                                                </tr>
                                                <tr>
                                                <td  class="text-right align-middle" width="33%"> Total casa: </td> <td>  <?php $ca_total_casa = $ca_total_tabla -$info_pago_cliente->ca_monto_pago; ?>  

                                                <?php echo number_format($ca_total_casa, 2, ',','.');  ?>  </td> 
                                                </tr>

                                            </table>

                                            


                                        <?php endif; ?>
                                </div>

                                        </div>

                                          </div>
                                            

                                


                                    </div>

                            <div class="row mt-4">

                                <div class="col-lg-12">

                                <div class="card card-custom gutter-b">
 <div class="card-header">
  <div class="card-title">
   <h3 class="card-label">
    Apuesta
    <small>informacion de la apuesta</small>
   </h3>
  </div>
 </div>
 <div class="card-body">
                                          <div class="col-lg-12">

                                            <div class="row">

                                <div class="col-lg-9">
                                        <div class="symbol-group symbol-hover">
                                        <div class="symbol symbol-circle mr-2">
                                            <img alt="Pic" src="<?php echo base_url(); ?>img/fichas/ficha5.png" onclick="apostar_ficha(5)"/>
                                        </div>
                                        <div class="symbol symbol-circle mr-2">
                                            <img alt="Pic" src="<?php echo base_url(); ?>img/fichas/ficha10.png" onclick="apostar_ficha(10)"/>
                                        </div>
                                        <div class="symbol symbol-circle mr-2">
                                            <img alt="Pic" src="<?php echo base_url(); ?>img/fichas/ficha20.png" onclick="apostar_ficha(20)"/>
                                        </div>
                                        <div class="symbol symbol-circle mr-2">
                                            <img alt="Pic" src="<?php echo base_url(); ?>img/fichas/ficha50.png" onclick="apostar_ficha(50)"/>
                                        </div>
                                        <div class="symbol symbol-circle mr-2">
                                            <img alt="Pic" src="<?php echo base_url(); ?>img/fichas/ficha100.png" onclick="apostar_ficha(100)"/>
                                        </div>
                                        </div>

                                    </div>


                                         <div class="col-lg-3 mt-2">
                                            <div class="form-group">
                                                        <div class="input-group ">
                                                           
                                                            <input type="text" class="form-control display-4" placeholder="Monto" name="ca_monto_apuesta" id="ca_monto_apuesta" readonly="readonly" value="0">
                                                            <div class="input-group-append">
                                                                <a class="btn btn-primary" onclick="limpiar_monto()">Limpiar</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                         </div>

                                         </div>


    


                            
                                          </div>
 </div>
</div>
                                        


    </div>
                                            
                                    </div>

                

                                  <?php if($info_sala->nb_estatus == 'FINALIZADO'): ?>

                                   <div class="row justify-content-center align-items-center minh-100">
                                        
                                        <div class="col-lg-6">

                                            <div class="card card-custom gutter-b">
                                                 <div class="card-header">
                                                  <div class="card-title">
                                                   <h3 class="card-label">
                                                    Resultados
                                                    <small>Iniciado</small>
                                                   </h3>
                                                  </div>
                                                 </div>
                                                 <div class="card-body  p-2">

                                                    <span id="div_reload_resultado_ganador">

                                                <?php if($sala_linea_posiciones->num_rows() > 0): ?>

                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-primary text-center align-middle" width="33%">Lugar</th>
                                                            <th class="text-primary text-center align-middle" width="33%">Ejemplar</th>
                                                            <th class="text-primary text-center align-middle" width="33%">Dividendo</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach ($sala_linea_posiciones->result() as $key): ?>
                                                        <tr>
                                                            <td class="text-center align-middle" scope="row"><?php if($key->nu_posicion == 1): ?> <b>Ganador</b>  <?php elseif($key->nu_posicion == 2): ?> <b>Place</b>  <?php else: ?> <?php echo $key->nu_posicion; ?> 

                                                            Lugar  <?php endif; ?> </td>

                                                            <td class="text-center align-middle"><?php echo $key->nu_casilla.' '.$key->nb_competidor; ?></td>
                                                            <td class="text-center align-middle"><?php echo $key->ca_dividendo; ?></td>
                                                        </tr>
                                                         <?php endforeach ?>

                                                    </tbody>
                                                </table>
   
                                                <?php else: ?>

                                                <h4 align="text-center">ESPERANDO RESULTADOS ...</h4>

                                                <?php endif; ?>

                                                </span>

                                                 </div>
                                                </div>
                                            


                                        </div>

                                    </div>


                                  <?php endif; ?> 


                                                <div class="row">


                                <div class="col-lg-4">
                                        <div class="card card-custom gutter-b">
                                                    <!--begin::Body-->
                                                    <div class="card-body d-flex align-items-center justify-content-between flex-wrap">
                                                        <div class="mr-2">
                                                            <h3 class="font-weight-bolder">Gaceta</h3>
                                                            <div class="text-dark-50 font-size-lg mt-2">fecha</div>
                                                        </div>
                                                        <a href="javascript:" onclick="ver_gaceta()" class="btn btn-primary font-weight-bold py-3 px-6">Ver ahora</a>
                                                    </div>
                                                    <!--end::Body-->
                                                </div>

                                    </div>


                                         <div class="col-lg-8 mt-2">


                                         </div>

                                         </div>




                                    

                            </div>


                            </div>

                            </div>
                            <!--end::Container-->
                        </div>
                        <!--end::Entry-->
                    </div>


    <div class="modal fade"  id="ajax_remote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog"  role="document">
        <div class="modal-content">

        </div>
    </div>
</div>


<script type="text/javascript">

    var co_sala = '<?php echo $info_sala->id; ?>';
    var nb_estatus = '<?php echo $info_sala->nb_estatus; ?>';
    var num_ganador = '<?php echo $sala_linea_posiciones->num_rows(); ?>';

setInterval(function(){ 

             $.ajax({
   method: "POST",
   data: {'co_sala':co_sala, 'nb_estatus':nb_estatus, 'num_ganador':num_ganador},
   url: "<?php echo site_url('carrera_caballo/cambios_sala') ?>",
            }).done(function(data) { 

                   var obj = JSON.parse(data);
                   
                        if (obj.cambios_estatus == 1) {

                        location.reload();

                       }

                        if (obj.cambios_ganador == 1) {

                            $("#div_reload_resultado_ganador").load('<?php echo site_url('carrera_caballo/reload_resultados/') ?>' + co_sala);

                       }
                              
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   

}, 5000);


   $(document).ready(function(){

   
      jQuery('#ajax_remote').on('hidden.bs.modal', function (e) {
    jQuery(this).removeData('bs.modal');
    jQuery(this).find('.modal-content').html('Cargando...');
   })
   

   }); // Fin ready
   

   function limpiar_monto() {
      $('#ca_monto_apuesta').val(0);
   }


function apostar_ficha(ca_monto_apuesta) {
    // body...
   var ca_monto_current =  $('#ca_monto_apuesta').val();
   var monto_sumar = parseInt(ca_monto_current) + parseInt(ca_monto_apuesta);
     $('#ca_monto_apuesta').val(monto_sumar);

     

}



         function ejecutar_apuesta(co_sala_linea, nu_posicion_apuesta)
   {

    var ca_monto_apuesta =  $('#ca_monto_apuesta').val();

    if (ca_monto_apuesta == 0) {
        toastr.error('ingrese el monto de la apuesta', 'Error');
        return;
    }
   
              $.ajax({
   method: "POST",
   data: {'co_sala_linea':co_sala_linea, 'nu_posicion_apuesta':nu_posicion_apuesta, 'ca_monto_apuesta':ca_monto_apuesta, 'co_sala':co_sala},
   url: "<?php echo site_url('carrera_caballo/ejecutar_apuesta') ?>",
            }).done(function(data) { 

                   var obj = JSON.parse(data);
                   
                        if (obj.error == 0) {

        $('#boton_accion_apuesta_ganadores_'+co_sala_linea+'_'+nu_posicion_apuesta).html('<a href="javascript:" class="btn btn-outline-success btn-circle"><i class="fas fa-check"></i></a>');
        $('#ca_monto_apostado_'+co_sala_linea+'_'+nu_posicion_apuesta).html(ca_monto_apuesta);
        $('#ca_monto_apuesta').val(0);
   

                       }else{
              
                          toastr.error(obj.message, 'Error');
                         return;

                       }
                              

   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   }

   


   
</script>
